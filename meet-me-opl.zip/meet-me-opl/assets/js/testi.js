
function ask() {
    var sta = "Please Drop a Message in the comment section Below!";


    return sta;

}

document.write(ask());
alert(ask());